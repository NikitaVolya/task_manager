
#include <iostream>
#include "ConsoleApplication.h"


int main()
{
	ConsoleApplication app;
	app.menu();
}